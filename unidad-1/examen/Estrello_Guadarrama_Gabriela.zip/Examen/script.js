let carrito = {};

function agregarAlCarrito(nombre, precio){
    if (carrito[nombre]){
        alert("Guitarra seleccionada, intenta con otro producto");
    }else{
        carrito[nombre] = nombre;
        alert('Usted agregó al carrito ' + nombre + ' con un precio de ' + precio);
    }
}